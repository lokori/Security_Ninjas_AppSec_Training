
function logoff(){
    document.cookie = "sessionID=e" ;
    window.location = "a8.html";
}